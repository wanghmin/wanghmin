Every pattern patch is stored as one OBJ file.

CL.sli contains the sewing lines in this format:
patch ID:node ID-patch ID:node ID

The garment.OBJ file is used for reference.

Some patterns contain a text file named as lr.eleg. It is used to label those edges whose rest lengths must be adjusted. The data format is:

mesh ID
node1 ID 	node2 ID	Adjustment ratio	(Stiffness, ignore this)

