MatrixXf m;
m.setZero(3, 3);
cout << m << endl;
